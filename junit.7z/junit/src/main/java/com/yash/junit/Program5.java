package com.yash.junit;
/**
 * 
 * @author tanay.ojha
 *
 */
public class Program5 {

}
