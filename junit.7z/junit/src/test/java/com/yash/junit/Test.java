package com.yash.junit;

public @interface Test {

}
