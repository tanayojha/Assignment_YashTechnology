package com.yash.junit;

import static org.junit.Assert.assertEquals;
import org.junit.Test;

/**
 * 
 * @author tanay.ojha
 *
 */
public class ProgramTest6 {
	Program6 s = new Program6();
	
    @Test
    public void testSumOfDigitFromExpression1(){  
    	assertEquals(2107,s.sumOfNumberDivideBy());  
    } 
    
    @Test
    public void testSumOfDigitFromExpression2(){  
    	
}
}
